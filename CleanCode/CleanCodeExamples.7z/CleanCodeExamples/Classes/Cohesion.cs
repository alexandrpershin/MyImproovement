public class Dirty
{
    public class Staff
    {
        bool IsPrinterWorking;
        int paperLeft;
        bool IsProjectActive;
        List<string> tasks;

        public Print(){
            if(IsPrinterWorking && paperLeft > 0){
                // do priting
            }
        }

        public List<string> getToDoTasks(){

            List<string> result = new List<string>();

            if(!IsProjectActive){
                return result;
            }

            foreach (var task in tasks)
            {
                if(!task.done){
                    result.Add(task);
                }
            }

            return result;
        }
    }
}

public class Clean
{

    public class OfficeManager
    {
        bool IsPrinterWorking;
        int paperLeft;

        public Print(){
            if(IsPrinterWorking && paperLeft > 0){
                // do priting
            }
        }
    }

    public class Developer
    {
        bool IsProjectActive;
        List<string> tasks;

        public List<string> getToDoTasks(){

            List<string> result = new List<string>();

            if(!IsProjectActive){
                return result;
            }

            foreach (var task in tasks)
            {
                if(!task.done){
                    result.Add(task);
                }
            }

            return result;
        }
    }
}