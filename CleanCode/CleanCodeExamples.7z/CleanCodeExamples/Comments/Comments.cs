public class CommentsDirty
{       
    public void DoSomething(string fileExtension)
    {
        // Check for valid file extension. Confirm if user can access
        if (fileExtension == "mp4" ||
            fileExtension == "mpg" ||
            fileExtension == "avi" &&
            (isAmind || isActiveFile))
        {
            play();    
        }
    }
}

public class CommentsClean
{         
    public void DoSomething(string fileExtension)
    {
        if (ValidFileRequest(fileExtension))
        {
            play();    
        }
    }
    
    private bool ValidFileRequest(string fileExtension)
    {
        List validFileExtensions = new List<string>() { "mp4", "mpg", "avi" };
        
        bool validFileType = validFileExtensions.Contains(fileExtension);
        bool userIsAllowedToViewFile = isActiveFile || isAdmin;
        
        return validFileType && userIsAllowedToViewFile;
    }
}
