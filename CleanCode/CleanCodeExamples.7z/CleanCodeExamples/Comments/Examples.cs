public class BadComment
{       
    public void Wrong()
    {
        // Check if employee can have benefits
        if ((DateTime.Now().Year - employee.dateHired.Year) > 2 && employee.isHourlyPayed)
        {
            giveBenifits();
        }
    }
    
    public void Correct()
    {
        if (employee.IsEligibleForBenefits())
        {
            giveBenifits();
        }
    }
}

public class GoodComment
{         
    public void DoSomething(string fileExtension)
    {
        // Search by Date format kk:mm:ss EEE, MMM, dd, yyyy
        Pattern timeMatcher = Pattern.compile("\\d*:\\d*:\\d* \\w*, \\w* \\d*, \\d*");
    }
}
