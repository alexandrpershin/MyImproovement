public class Dirty
{

    private void Start()
    {       
        int x = 10;

        if(x == 1){
            // do action 1
        }
        else if (x == 2){
            // do action 2
        }
        else if (x == 3){
            // do action 3
        }
        else if (x == 4){
            // do action 4
        }  
    }
}

public class Clean
{
    
    private void Start()
    {       
        int x = 10;

        switch (x)
        {
            case 1:
                // do action 1
                break;
            case 2:
                // do action 2
                break;
            case 3:
                // do action 3
                break;
            case 4:
                // do action 4
                break;
            default:
                // log error
        }
    }
}

public class Dirty2{

    private void Start(int number)
    { 
        if (number > 0){
            // do something
            // do another thing
            // do a lot of stuff
            // some nested loops and ifs
        }
    }
}

public class Clean2{

    private void Start(int number)
    {       
        if (number < 0){
            return;
        }

        // do something
        // do another thing
        // do a lot of stuff
        // some nested loops and ifs
    }
}