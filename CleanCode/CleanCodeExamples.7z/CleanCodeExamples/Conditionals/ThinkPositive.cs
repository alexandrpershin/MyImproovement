﻿namespace CleanCode.Conditionals
{
    public class ThinkPositiveClean
    {
        class Meeting
        {
            public bool IsApproved;
        }

        Meeting meeting = new Meeting();

        public void Example()
        {
            if (meeting.IsApproved)
            {
                // Start presenting
            }
        }
    }

    public class ThinkPositiveDirty
    {
        class Meeting
        {
            public bool NotApproved;
        }

        Meeting meeting = new Meeting();

        public void Example()
        {
            if (!meeting.NotApproved)
            {
                // Start presenting
            }
        }
    }
}
