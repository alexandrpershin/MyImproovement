public class DefineNormalFlowDirty
{
    public void Start()
    {
        try
        {
            MealExpenses expenses = expenseReport.GetMeals(employee.Id);
            total += expenses.GetTotal();
        }
        catch (MealExpensesNotFound e)
        {
            total += getStandardMeal();
            throw;
        }
    }

    public class MailExpenses
    {
        private int GetTotal()
        {
            if(employee.Id != null)
            {
                return employee.MealPrice;
            }

            throw new MealExpensesNotFound();
        }
    }
}


public class DefineNormalFlowClean
{
    public void Start()
    {
        MealExpenses expenses = expenseReport.GetMeals(employee.Id);
        total += expenses.GetTotal();
    }
    
    public class MailExpenses
    {
        private int GetTotal()
        {
            if(employee.Id != null)
            {
                return employee.MealPrice;
            }

            return getStandardMeal();
        }
    }
}