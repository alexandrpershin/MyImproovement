public class FailFastDirty
{
    public void RegisterUser(string username, string password)
    {
        if (!string.IsNullOrWhiteSpace(username))
        {
            if (!sting.IsNullOrWhiteSpace(password))
            {
                registerUser(username,password);
            }
            else
            {
                throw new ArgumentException("username is required");
            }
        }
        else
        {
            throw new ArgumentException("password is required");
        }
    }
}


public class FailFastClean
{
    public void RegisterUser(string username, string password)
    {
        if (sting.IsNullOrWhiteSpace(username)) throw new ArgumentException("username is required");   // Guard
        if (sting.IsNullOrWhiteSpace(password)) throw new ArgumentException("password is required");   // Clauses
        
        registerUser(username,password);
    }
}