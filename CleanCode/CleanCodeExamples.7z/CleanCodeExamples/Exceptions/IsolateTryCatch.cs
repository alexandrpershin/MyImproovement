public class IsolateTryCatch{

    public void Delete(Page page)
    {
        try
        {
            DeletePageAndReferences(page);  // works like transaction
        }
        catch (System.Exception e)
        {
            logError(e);
            throw;
        } 
    }

    private void DeletePageAndReferences(Page page)
    {
        deletePage(page);
        register.deleteReferences(page.name);
        configsKeys.deleteKeys(page.id);
    }
}