namespace CleanCode.Formatting
{
    public class FormattingClean
    {
        public string Name;
        private int variableOne;
        private int variableTwo;
    
        public FormattingClean(int x, int y)
        {
            this.variableOne = x;
            this.variableTwo = y;
        }
    
        public void DoSomething(int x, int y)
        {
            SomeCalculations(variableOne, variableTwo);
        }
    
        private int SomeCalculations(int x, int y)
        {
            int result = x + y + 100;
            SaveResultsToFile(result);
                    
            return result;
        }
    
        private void SaveResultsToFile(int result)
        {
            //Save Results
        }
    }

    public class FormattingDirty
    {
        private int SomeCalculations(int x,int y)
        {
               int Result=x+y+100;SaveResultsToFile(Result);     
            return Result;
        } public string name;
        private void SaveResultsToFile(int result){
            //Save Results
        }
        public void DoSomething(int x, int y){SomeCalculations(variableOne,variableTwo);}
        private int variableOne; private int variableTwo;
        public FormattingDirty(int x,int y)
        {
            this.variableOne=x; this.variableTwo=y;
        }
    }
}