public class Story{
    
    public void HiJohn()
    {
        if(contract.isApproved){
            send(email);
        }
    }

    public void HelloJohn()
    {
        goTo("myOffice");
        take("documents");
        sign("documents");

        if(haveNoOtherTasks){
            goHome();
        }
    }
}