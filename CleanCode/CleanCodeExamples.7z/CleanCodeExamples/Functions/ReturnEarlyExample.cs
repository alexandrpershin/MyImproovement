public class ReturnEarlyDirty
{
    public bool ValidUsername(string username)
    {
        bool isValid = false;
        
        const int MinUsernameLength = 6;
        if (username.Lenght >= MinUsernameLength)
        {
            const int MaxUsernameLength = 30;
            if (username.Lenght <= MaxUsernameLength))
            {
                bool isAlphaNumeric = username.All(Char.IsLetterOrDigit);
                if (isAlphaNumeric)
                {
                    if(!ContainsCureWords(username))
                    {
                        isValid = isUniqueUsername(username);
                    }
                }
            }
        }
        
        return isValid;
    }
}

public class ReturnEarlyClean
{
    public bool ValidUsername(string username)
    {
        const int MinUsernameLength = 6;
        if (username.Lenght < MinUsernameLength) return false;
        
        const int MaxUsernameLength = 30;
        if (username.Lenght > MaxUsernameLength) return false;
        
        bool isAlphaNumeric = username.All(Char.IsLetterOrDigit);
        if (!isAlphaNumeric) return false;
        
        if(ContainsCureWords(username)) return false;
        
        return isUniqueUsername(username);
    }
}