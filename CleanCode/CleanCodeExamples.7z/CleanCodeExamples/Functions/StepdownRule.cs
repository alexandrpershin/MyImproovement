public class StepDownRule
{
    private bool isMainPage;
    private PageData pageData;
    private WikiPage testPage;
    private PageCrawler pageCrawler;
    private StringBuilder newPageContent;
    
    public string Render(PageData pageData, bool isMainPage)
    {
        SetupPage(pageData, isMainPage);
        return GetPage();
    }
    
    private void SetupPage(PageData pageData, bool isMainPage)
    {
        this.pageData = pageData;
        this.isMainPage = isMainPage;
        testPage = pageData.getWikiPage();
        pageCrawler = testPage.getPageCrawler();
        newPageContent = new StringBuilder();
    }
    
    private string GetPage()
    {
        if (IsMainPage)
        {
            IncludeMainContent();
        }
        return pageData.getHtml();
    }
    
    private void IncludeMainContent()
    {
        IncludeHeader();
        IncludeContent();
        IncludeFooter();
        UpdatePageContent();
    }
    
    private void IncludeSetupPage()
    {
        Include("Navbar");
    }
    
    private void IncludePageContent()
    {
        Include("WikiInfo");
    }
    
    private void IncludeFooter()
    {
        Include("Footer");
    }
    
    private void Include(string componentName)
    {
        string path = FindComponentPath(componentName);
        if(path != null)
        {
            BuildByTemplate(path);
        }
    }
    
    private string FindComponentPath(string componentName)
    {
        RootFolder root = Helper.GetRootFolder();
        string componentPath = root.Find(componentName);
        
        return componentPath;
    }
    
    private string BuildByTemplate(string path)
    {
        string template = Helper.GetByPath(path);
        template.replace("<br>", "\n");
        template.replace("&", "");
        
        return template;
    }
    
    private void UpdatePageContent()
    {
        pageData.SetContent(newPageConent.ToString());
    }    
}