variables; 
BAD NAMES:
data
rgstrUsrs
emails_For_Contacts
_accounts
COTList
Number

GOOD NAMES:
userInfo
registeredUsers
emailsForContacts
accounts
currentOpenTasksList
taskCounter


functions:
BAD NAMES:
User
Set_Attribute
MarkAndSave
SendOrClear

GOOD NAMES:
GetUser
SetAttribute
Send
Clear

clases:
BAD NAMES:
ManagerDataProcessorMakeCreate

GOOD NAMES:
AccountUserServiceCreator


booleans:
BAD NAMES:
approve
clearing
notDone

GOOD NAMES:
isApproved
cleared
finished



    
    