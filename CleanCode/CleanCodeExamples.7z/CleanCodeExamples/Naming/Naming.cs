using System.Collections.Generic;

namespace CleanCode.Naming
{
    public class NamingDirty
    {   
        public List<int> GetThem(int[] numbers)
        {
            List<int> list1 = new List<int>();
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == 0)
                {
                    list1.Add(numbers[i]);
                }
            }
        
            return list1;
        }
    }

    public class NamingClean
    {         
        public List<int> GetEmptyCells(int[] gameBoard)
        {
            List<int> emptyCells = new List<int>();
            int EMPTY = 0;
        
            for (int i = 0; i < gameBoard.Length; i++)
            {
                if (gameBoard[i] == EMPTY)
                {
                    emptyCells.Add(gameBoard[i]);
                }
            }
        
            return emptyCells;
        }
    }
}