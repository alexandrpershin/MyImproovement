
var myWindow ;

function openChildWindow() {
  myWindow = window.open('', 'Gasperoid Window', 'height=200, width=200') ;  // Open a new window
  myWindow.document.title = "Termopan" ;  // Change default title
  myWindow.document.write("<h1>Child Window</h1>") ;
  myWindow.document.write("<h3>Hello, World !</h3>") ;
  // myWindow.location = "https://google.com" ;
  myWindow.resizeTo(1000, 700) ;

  myWindow.moveBy(-200, 400) ;

}

function closeChildWindow() {
  myWindow.close() ;
}

function closeInSecWindow() {
  myWindow.setTimeout(function() {
    myWindow.close() ;
  }, 5000) ;
}

function printChildWindow() {
  myWindow.print() ;
}


function resizeChildWindow() {
  myWindow.resizeTo(200, 300) ;
}

function moveChildWindow() {
  myWindow.moveBy(100, 100) ;
}
