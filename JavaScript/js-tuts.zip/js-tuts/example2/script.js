
var element, text ;

function createH2() {
  element = document.createElement("h2") ;
  console.log("New h2 created") ;
}

function addText() {
  text = document.createTextNode("Hello, World!") ;
  console.log("New TextNode created !") ;
}

function appendText() {
  element.appendChild(text) ;
  console.log("Append Text to Element") ;
}

function appendToBody() {
  document.body.appendChild(element) ;
}

function addStyle() {
  element.style = "color:#f00" ;
}
