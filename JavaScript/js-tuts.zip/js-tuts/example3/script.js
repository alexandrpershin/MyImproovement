
var element, list, li, firstLi, lastLi;

function getList() {
  list = document.getElementById('cities') ;
  console.log(list) ;
}

function getFirstElement() {
  // firstLi = list.firstChild ;
  firstLi = list.firstChild.nextElementSibling ;
  console.log(firstLi) ;
}

function changeText() {
  var text = window.prompt("Enter a city: ") ;
  firstLi.innerHTML = text ;
}

function deleteLastElement() {
  // lastLi = list.lastChild.previousElementSibling ;
  lastLi = list.lastElementChild ;
  list.removeChild(lastLi) ;
}


function insertBefore2() {
  var li = document.createElement("li") ;
  li.innerText = "Hello !" ;
  list.insertBefore(li, firstLi) ;
}
