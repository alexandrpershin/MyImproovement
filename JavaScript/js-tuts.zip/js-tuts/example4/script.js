var xhttp = new XMLHttpRequest() ;


function getRequest() {
  xhttp.onreadystatechange = function() {
    if(xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById('header2').innerHTML = xhttp.responseText  ;
    }
  }

  xhttp.open("GET", "server.php", true) ;
  xhttp.send() ;

}


function postRequest() {
    var fullName = prompt("Enter your name: ") ;
    xhttp.onreadystatechange = function() {
      if(xhttp.readyState == 4 && xhttp.status == 200) {
        document.getElementById('header2').innerHTML = JSON.parse(xhttp.responseText)  ;
      }
    }

    xhttp.open("POST", "server.php", true) ;
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("fullName="+fullName) ;
}
