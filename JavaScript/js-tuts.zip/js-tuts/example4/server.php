<?php
if($_SERVER['REQUEST_METHOD'] == "GET") {
  echo "GET RESPONSE" ;
}

if($_SERVER['REQUEST_METHOD'] == "POST") {
  echo json_encode("Welcome, ". $_POST['fullName']) ;
}


?>
